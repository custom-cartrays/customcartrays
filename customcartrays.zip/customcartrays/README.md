# Custom Car Trays — Design Studio

Sitio web para diseñar bandejas de auto personalizadas con IA integrada.

## Deploy rápido en Vercel

### Opción A — GitHub + Vercel (recomendado)

1. Crea un repositorio en github.com
2. Sube estos archivos al repo
3. Ve a vercel.com → "New Project" → importa el repo
4. Vercel detecta Vite automáticamente → clic "Deploy"
5. En Settings → Domains → agrega `customcartrays.com`
6. En GoDaddy DNS → agrega los 2 registros que Vercel te da

### Opción B — Vercel CLI

```bash
npm install
npm run build
npx vercel --prod
```

## Desarrollo local

```bash
npm install
npm run dev
```

Abre http://localhost:5173

## Tecnología

- React 18 + Vite
- fal.ai (Flux Pro) para generación y outpainting
- 300 DPI export · 16.5" × 11" · customcartrays.com
